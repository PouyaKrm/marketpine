# Create your tests here.
#
# factory = APIRequestFactory()
#
# request = factory.post('/salesperson/create/', {'username': 'jack'}, format='json')
#
# data = views.create_user(request)
#
# print(data)
